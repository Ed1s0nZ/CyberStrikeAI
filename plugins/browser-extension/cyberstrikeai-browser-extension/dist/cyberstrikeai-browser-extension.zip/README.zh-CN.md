## CyberStrikeAI 浏览器扩展（中文说明）

**当前版本：0.3.5**

Chrome / Edge（Chromium）DevTools 扩展：捕获 **Network** 流量，发送到 CyberStrikeAI 做 AI 辅助安全测试。与 Burp 插件能力对齐。

### 功能

- **Background 中枢**：Network 捕获 → background 队列 → DevTools 面板订阅
- **Test History**：最多 50 条，可回看 Progress / Final
- **Captured Requests**：每 Tab 最多 200 条；默认 **XHR/Fetch only**
- **HTTP/1.1 归一化**：存储原始 HAR；展示与 AI Prompt 去除 `:method` 等伪首部（与 Burp 对齐）
- **捕获开关**：**● 捕获中** / **○ 已暂停** — 暂停后不读响应体、不写入列表（Send 仍可用）
- SSE 流式输出；Progress **512KB** 上限；Final 不截断（历史 run 软截断 100KB）
- Markdown 延迟渲染；超 100KB 降级纯文本
- 性能：过滤器内存缓存、静态资源不读 body、rAF 节流、列表增量插入
- **Latest XHR** / **Copy** / **Stop**（本地 + 服务端 cancel）
- Token 存 **session**；**optional_host_permissions**

### 数据上限（不会无限增长）

| 数据 | 上限 | 存储 |
|------|------|------|
| 捕获请求 | 200 条/Tab | 内存 |
| Tab 队列 | 20 个 Tab | 内存 |
| 测试历史 | 50 条 | Panel 内存 |
| 配置/Token | 极小 | chrome.storage |

关 DevTools 后 Panel 数据清空；关浏览器后 Token 失效。

### 性能说明

- **未开 DevTools**：对页面速度无影响
- **开了 DevTools**：仅对匹配的 XHR/Fetch 有轻微捕获开销；建议保持 XHR/Fetch only

### 安装

1. `chrome://extensions/` → 开发者模式 → **加载已解压的扩展程序**
2. 目录：`plugins/browser-extension/cyberstrikeai-browser-extension/`
3. 目标页 **F12** → **CyberStrikeAI** 面板 → Validate
4. 扩展更新后需 **关闭 DevTools 再打开**，避免上下文失效

### 打包

```bash
bash plugins/browser-extension/cyberstrikeai-browser-extension/package.sh
# → dist/cyberstrikeai-browser-extension.zip
```

### 限制

- Chrome 无 Network 右键菜单 API；用 **Latest XHR** + 自建列表替代
- Firefox 需 `about:debugging` 临时加载

### 目录

```text
manifest.json
background/service-worker.js
devtools.js
panel/                    # 主 UI（连接、Send、Output）
popup/                    # 只读状态 + 引导
lib/                      # api, storage, capture, http-normalize, markdown
package.sh
```
