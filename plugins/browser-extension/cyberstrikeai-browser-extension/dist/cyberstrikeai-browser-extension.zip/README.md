## CyberStrikeAI Browser Extension

**Version 0.3.5** — see **README.zh-CN.md** for full documentation.

### Quick install

1. `chrome://extensions/` → Developer mode → **Load unpacked**
2. Select this folder
3. DevTools (F12) → **CyberStrikeAI** tab → Validate

### Popup vs DevTools panel

| Location | Purpose |
|----------|---------|
| **DevTools panel** | Connection config, Validate, capture, Send, Output |
| **Extension popup** | Read-only connection status + quick guide |

Connection settings stay in the DevTools panel (primary workflow). The popup shows whether you are connected and which endpoint is configured.

### Package

```bash
bash package.sh
```

Output: `dist/cyberstrikeai-browser-extension.zip`

### Data limits

- 200 captures/tab, 50 test runs, 512KB progress cap — all in-memory, cleared when DevTools closes
- Config/token only in `chrome.storage` (small)
